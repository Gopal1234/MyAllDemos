package com.org.util;

import org.springframework.stereotype.Component;
import org.springframework.hateoas.EntityModel;

import com.org.controller.EmployeeController;
import com.org.model.Employee;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;


import org.springframework.hateoas.server.mvc.RepresentationModelAssemblerSupport;

@Component
public class EmployeeModelAssembler extends RepresentationModelAssemblerSupport<Employee, EntityModel<Employee>> {

	public EmployeeModelAssembler() {
	    super(EmployeeController.class, (Class<EntityModel<Employee>>) (Class<?>) EntityModel.class);
	}



    @Override
    public EntityModel<Employee> toModel(Employee employee) {
        return EntityModel.of(employee,
                linkTo(methodOn(EmployeeController.class).getEmployeeById(employee.getId())).withSelfRel(),
                linkTo(methodOn(EmployeeController.class).getAllEmployees()).withRel("employees"));
    }
}
