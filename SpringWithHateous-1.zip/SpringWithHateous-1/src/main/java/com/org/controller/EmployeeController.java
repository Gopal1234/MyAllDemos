package com.org.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.IanaLinkRelations;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;


import com.org.model.Employee;
import com.org.util.EmployeeModelAssembler;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    private final List<Employee> employees = new ArrayList<>();
    private final EmployeeModelAssembler assembler;
    private Long idCounter = 1L;

    public EmployeeController(EmployeeModelAssembler assembler) {
        this.assembler = assembler;
        employees.add(new Employee(idCounter++, "Gopal", "Trainer"));
        employees.add(new Employee(idCounter++, "Sourav", "Manager"));
    }

    @GetMapping("/{id}")
    public EntityModel<Employee> getEmployeeById(@PathVariable Long id) {
        Employee emp = employees.stream()
                .filter(e -> e.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));
        return assembler.toModel(emp);
    }

    @GetMapping
    public CollectionModel<EntityModel<Employee>> getAllEmployees() {
        List<EntityModel<Employee>> employeeModels = employees.stream()
                .map(assembler::toModel)
                .toList();

        return CollectionModel.of(employeeModels,
                linkTo(methodOn(EmployeeController.class).getAllEmployees()).withSelfRel());
    }

 
}

