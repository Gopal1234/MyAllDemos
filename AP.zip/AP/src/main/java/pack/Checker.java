package pack;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;
@Component
public class Checker {
	int[] ids=new int[] {12,45,67,89};
	
	public String getId(int id)
	{
		for(int i=0; i<ids.length; i++)
		{
			if(ids[i]==id)
			{
				
				return "Your id is valid";
				
			}
			
		
		}
		return "not valid";
	}
	

}
