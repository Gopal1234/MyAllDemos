package pack;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//import com.cognizant.pack1.MyClass;  
public class Test{  
    public static void main(String[] args){  
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        MyAccount m = (MyAccount) context.getBean("myAccount");  
        Scanner scanner=new Scanner(System.in);  
        System.out.println("Enter amount to withdraw");
        double amt=scanner.nextDouble();
     System.out.println("Your balance is"+   m.withdraw(amt));
     System.out.println("Enter amount to deposit");
     double deposit_amt=scanner.nextDouble();
  System.out.println("Your balance is"+   m.deposit(deposit_amt));
        
    }  
}  