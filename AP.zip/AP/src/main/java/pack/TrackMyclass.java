package pack;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;  
import org.aspectj.lang.annotation.Before;  
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;  
  /*
   * before call
   * after call
   * after return
   * after throw
   * 
   * 
   */
@Aspect 
@Component
@EnableAspectJAutoProxy
public class TrackMyclass{  
   /* @Pointcut("execution(public * *(..))")  
    public void t(){}*/
    //pointcut name  
	//execution(*MyAccount.*(..))
	//execution( public MyAccount.set*(..))
      //@Before(t())
    @Before("execution(public * *(..))")//applying pointcut on before advice  
    public void myadvice(JoinPoint jp)//it is advice (before advice)  
    {  
    	System.out.println(jp.getSignature().getName()+" "+jp.getSignature().getModifiers());
    	Scanner scanner =new Scanner(System.in);
    	System.out.println("enter id");
    	int id=scanner.nextInt();//14
    	Checker chk=new Checker();
    	String s=chk.getId(id);
    	if(s.equals("Your id is valid"))
    	{
    	System.out.println(s);
    	}
    	else
    	{
    		System.out.println(s);
    		System.exit(0);
    	}
        
    }  
}  