package pack;

import org.springframework.stereotype.Component;

@Component
//myAccount
public class MyAccount {
	double amount=5000.00;
	
	/*
	 * before calling withdraw or deposit method I want to check
	 * whether user is valid or not 
	 * 
	 * we have define a method which will authenticate the user
	 * we have to call that method from every method of MyAccount
	 * 
	 */
	public double withdraw(double amount)
	{
		this.amount=this.amount-amount;
		return this.amount;
	}public double deposit(double amount)
	{
		this.amount=this.amount+amount;
		return this.amount;
	}

}
