package com.org.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.org.model.Train;

import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@Tag(name = "Train Controller", description = "Train management APIs")
public class MyController {
	
	
	@GetMapping("/show-msg")
	public String showWelcomeMsg()
	{
		return "<h3><font color='blue'>Hi...</font></h3>";
	}
	
	@PostMapping("create-train")
	public Train createTrain(@RequestBody Train train)
	{
		return  train;
	}

}
